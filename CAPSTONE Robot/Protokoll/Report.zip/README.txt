This software solves a maze problem, where a robot has a initial position and some sensor data that permit its
to know where in its surrounding there is a wall. The goal is to get to the center in two runs, the first one to explore
and try to map the maze and the second run to go to the center as fast as possible. The algorithm to find the fastest
way is A*, while the exploring part is a 'swing' stategy going from the center to some key points to map the maze. 

The only necessary extra library is numpy. 

author: Thiago Henrique Gomes Lobato. thiagohgl@hotmail.com